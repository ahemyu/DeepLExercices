class BaseLayer:
    def __init__(self, trainable: bool = False):
        self.trainable = trainable
        